import pandas as pd

df = pd.read_csv('../Datasets/customer_transactions.csv')
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
df = df.drop_duplicates()
df = df.fillna(0)

df.to_csv('../Datasets/customer_transactions_cleaned.csv', index=False)
print('ETL completed: cleaned dataset saved.')
