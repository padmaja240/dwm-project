CREATE TABLE customer_transactions (
    InvoiceID VARCHAR(20),
    InvoiceDate DATE,
    CustomerID VARCHAR(20),
    CustomerName VARCHAR(100),
    ProductID VARCHAR(20),
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    Region VARCHAR(50),
    Quantity INT,
    UnitPrice DECIMAL(10,2),
    Discount DECIMAL(10,2),
    Amount DECIMAL(10,2),
    PaymentMode VARCHAR(50)
);
